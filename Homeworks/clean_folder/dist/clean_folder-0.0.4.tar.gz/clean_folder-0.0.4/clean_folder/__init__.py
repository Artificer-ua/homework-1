from clean_folder.clean import main

__all__ = ['main']